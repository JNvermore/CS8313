
public class AppleWatchNikePlus implements Watch{

	@Override
	public String orderWatch() {
		return "You ordered an Apple Watch Nike+.";
	}

}
