
public interface Computer {
	public String orderComputer();
}
