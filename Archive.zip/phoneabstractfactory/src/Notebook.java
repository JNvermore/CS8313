
public class Notebook implements Computer {

	@Override
	public String orderComputer() {
		return "Notebook.";
	}

}
