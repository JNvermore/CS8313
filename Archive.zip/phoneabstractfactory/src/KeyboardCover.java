
public class KeyboardCover implements Accessory {

	@Override
	public String accessoryItem() {
		return "Keyborad Cover.";
	}

}
