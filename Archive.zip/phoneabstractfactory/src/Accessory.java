
public interface Accessory {
	public String accessoryItem();
}
