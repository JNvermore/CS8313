
public class GalaxyTabS2 implements Tablet {

	@Override
	public String tabletItem() {
		return "Galaxy Tab S2.";
	}

}
