
public class IPadMini4 implements Tablet{

	@Override
	public String tabletItem() {
		return "iPad Mini 4.";
	}

}
