
public class GearS3 implements Watch {

	@Override
	public String orderWatch() {
		return "Gear S3.";
	}

}
