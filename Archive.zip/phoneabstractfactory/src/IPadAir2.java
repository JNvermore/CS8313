
public class IPadAir2 implements Tablet {

	@Override
	public String tabletItem() {
		return "iPad Air 2.";
	}

}
