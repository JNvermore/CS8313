
public class GalaxyTabProS implements Tablet {

	@Override
	public String tabletItem() {
		return "Galaxy TabPro S";
	}

}
