
public interface Tablet {
	public String tabletItem();
}
