
public class IPadPro implements Tablet {

	@Override
	public String tabletItem() {
		return "iPad Pro";
	}

}
