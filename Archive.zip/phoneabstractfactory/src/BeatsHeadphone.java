
public class BeatsHeadphone implements Accessory {

	@Override
	public String accessoryItem() {
		return "Beats Headphones.";
	}

}
