
public class GearS2 implements Watch {

	@Override
	public String orderWatch() {
		return "Gear S2.";
	}

}
