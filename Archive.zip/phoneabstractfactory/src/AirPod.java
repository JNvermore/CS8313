
public class AirPod implements Accessory{

	@Override
	public String accessoryItem() {
		return "AirPod.";
	}

}
