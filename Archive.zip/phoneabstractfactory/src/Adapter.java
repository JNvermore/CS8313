
public class Adapter implements Accessory {


	@Override
	public String accessoryItem() {
		return "Adapter.";
	}

}
