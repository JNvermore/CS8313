
public class MacBook implements Computer {

	@Override
	public String orderComputer() {
		return "MacBook.";
	}

}
