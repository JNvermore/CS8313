
public class AppleWatchSeries2 implements Watch{

	@Override
	public String orderWatch() {
		return "You ordered an Apple Watch Series 2.";
	}

}
