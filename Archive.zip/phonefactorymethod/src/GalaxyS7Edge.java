
public class GalaxyS7Edge extends SmartPhone{
	public GalaxyS7Edge() {
		name = "Galaxy S7 Edge";
		storeName = "Samsung Online Store";
	}
}
