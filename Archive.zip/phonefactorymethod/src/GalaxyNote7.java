
public class GalaxyNote7 extends SmartPhone{
	public GalaxyNote7 () {
		name = "Galaxy Note 7";
		storeName = "Samsung Online Store";
	}
}
