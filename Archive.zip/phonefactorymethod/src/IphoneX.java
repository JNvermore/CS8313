
public class IphoneX extends SmartPhone{
	public IphoneX() {
		name = "IphoneX";
		storeName = "Apple Online Store";
	}
}
