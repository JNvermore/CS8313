
public class Iphone8 extends SmartPhone{
	public Iphone8() {
		name = "Iphone 8";
		storeName = "Apple Online Store";
	}
}
