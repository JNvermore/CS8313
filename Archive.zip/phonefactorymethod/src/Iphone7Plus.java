
public class Iphone7Plus extends SmartPhone{
	public Iphone7Plus() {
		name = "Iphone 7 Plus";
		storeName = "Apple Online Store";
	}
}
